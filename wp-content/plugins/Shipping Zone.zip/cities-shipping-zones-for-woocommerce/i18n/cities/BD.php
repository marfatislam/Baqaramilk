<?php

/**
 * List of cities for: Bangladesh
 * Source: http://www.bbs.gov.bd/site/page/47856ad0-7e1c-4aab-bd78-892733bc06eb/
 * Version: 1.0
 * Author: Condless
 * Author URI: https://www.condless.com/
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 */

/**
 * Exit if accessed directly
 */
defined( 'ABSPATH' ) || exit;

$country_states = [
	
	'BD30'	=> 'Dhaka',
	
];

$country_cities = [
	'BD30' => [
	'Azampur' => 'Azampur',
	'Azimpur' => 'Azimpur',
	'Aftabnagar' => 'Aftabnagar',
	'Arambag' => 'Arambag',
	'Adabar' => 'Adabar',
	'Agargao' => 'Agargao',
	'Adarshanagar' => 'Adarshanagar',
	'Badda' => 'Badda',
	'Baruntek' => 'Baruntek',
	'Bangsal' => 'Bangsal',
	'Bailey Road' => 'Bailey Road',
	'Bimanbandar' => 'Bimanbandar',
	'Banani' => 'Banani',
	'Baridhara' => 'Baridhara',
	'Bashundhara' => 'Bashundhara',
	'Bangla Motor' => 'Bangla Motor',
	'Bashaboo' => 'Bashaboo',
	'Banasree' => 'Banasree',
	'Badda' => 'Badda',
	'Cantonment' => 'Cantonment',
	'Chowkbazar' => 'Chowkbazar',
	'Dhaka' => 'Dhaka',
	'Darus Salam' => 'Darus Salam',
	'Demra' => 'Demra',
	'Dhanmondi' => 'Dhanmondi',
	'Dhaka University' => 'Dhaka University',
	'DOHS Banani' => 'DOHS Banani',
	'DOHS Mirpur' => 'DOHS Mirpur',
	'DOHS Mohakhali' => 'DOHS Mohakhali',
	'DOHS Baridhara' => 'DOHS Baridhara',
	'Easkaton' => 'Easkaton',
	'Farmgate' => 'Farmgate',
	'Gendaria' => 'Gendaria',
	'Green Road' => 'Green Road',
	'Gulshan' => 'Gulshan',
	'Gabtoli' => 'Gabtoli',
	'Hazaribagh' => 'Hazaribagh',
	'Hatirpool' => 'Hatirpool',
	'HatirJhil' => 'HatirJhil',
	'Indira Road' => 'Indira Road',
	'Islampur'=> 'Islampur',
	'Jatrabari' => 'Jatrabari',
	'Jigatola' => 'Jigatola',
	'Kafrul' => 'Kafrul',
	'Kalshi' => 'Kalshi',
	'Kalabagan' => 'Kalabagan',
	'Kamrangirchar' => 'Kamrangirchar',
	'Khilgaon' => 'Khilgaon',
	'Khilkhet ' => 'Khilkhet',
	'Kamlapur' => 'Kamlapur',
	'Kallayanpur' => 'Kallayanpur',
    'Kochukhet' => 'Kochukhet',  
	'Lalbagh' => 'Lalbagh',
	'Lalmatia' => 'Lalmatia',
	'Mirpur 1-6' => 'Mirpur 1-6',
 	'Mirpur 10-14' => 'Mirpur 10-14',
	'Mohammadpur' => 'Mohammadpur',
	'Motijheel' => 'Motijheel',
	'Mahanagar' => 'Mahanagar',
	'Matikata' => 'Matikata',
	'Merul Badda' => 'Merul Badda',
	'Manik Nagar' => 'Manik Nagar',
	'Monipur' => 'Monipur',
	'Monipuripara' => 'Monipuripara',
	'Mouchak' => 'Mouchak',
	'Malibag' => 'Malibag',
	'Magbazar' => 'Magbazar',
	'Mohakhali' => 'Mohakhali',
	'New Market Thana' => 'New Market Thana',
	'New Paltan' => 'New Paltan',
	'New Eskaton' => 'New Eskaton',
	'Naya paltan' => 'Naya paltan',
	'Nikunja' => 'Nikunja',
	'Niketon' => 'Niketon',
	'Nakhalpara' => 'Nakhalpara',
	'Pallabi' => 'Pallabi',
	'Paltan' => 'Paltan',
	'Panthapath' => 'Panthapath',
	'Paikepara' => 'Paikepara',
	'Purbo Rajarbazar' => 'Purbo Rajarbazar',
	'Poshchim Rajarbazar' => 'Poshchim Rajarbazar',
	'Polashi' => 'Polashi',
	'Ramna' => 'Ramna',
	'Rampura' => 'Rampura',
	'Rayerbag' => 'Rayerbag',
	'Rajarbazar' => 'Rajarbazar',
	'Sabujbagh' => 'Sabujbagh',
	'Sobhanbag' => 'Sobhanbag',
	'Shahbag' => 'Shahbag',
	'Shantibag' => 'Shantibag',
	'Sher-e-Bangla Nagar' => 'Sher-e-Bangla Nagar',
	'Shyampur ' => 'Shyampur',
	'Shyamoli' => 'Shyamoli',
	'Shajanpur' => 'Shajanpur',
	'Shahjadpur' => 'Shahjadpur',
	'Sutrapur' => 'Sutrapur',
	'Shat Mashjid Road' => 'Shat Mashjid Road',
	'Shiddeshwari' => 'Shiddeshwari',
	'Shankar' => 'Shankar',
	'Tejgao' => 'Tejgao',
	'Tikatuli' => 'Tikatuli',
    'Vatara' => 'Vatara',
    'Vashantek' => 'Vashantek',  
	'Uttar Khan' => 'Uttar Khan',
	'Uttara' => 'Uttara',
	'Wari' => 'Wari',
	'West Kafrul' => 'West Kafrul',
	],
	
];








	
      